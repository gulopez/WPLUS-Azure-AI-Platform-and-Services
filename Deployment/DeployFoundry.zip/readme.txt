.\Deploy-Foundry.ps1 -ResourceGroupName "azureaiworkshoprg" -FoundryName "ai-foundry-59483770" -ProjectName "firstProject"


.\Get-FoundryInfo.ps1 -ResourceGroupName "azureaiworkshoprg" -FoundryName "ai-foundry-59483770" -ProjectName "firstProject"